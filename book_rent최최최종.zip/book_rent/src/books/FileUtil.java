package books;

import java.io.File;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import board.BoardDTO;

public class FileUtil {
	
	private final String  saveDirectory = "F:\\upload";
	private final int maxPostSize = 20 * 1024 * 1024 ;
	private final String encoding = "UTF-8";
	private final FileRenamePolicy policy = new DefaultFileRenamePolicy();
	
	private static FileUtil instance = new FileUtil();
	
	public static FileUtil getInstance() {
		return instance;
	}
	
	private FileUtil() {
		File dir = new File(saveDirectory);
		if(dir.exists() == false) {
			dir.mkdirs();
		}
	}
	
	public BooksDTO getDTO(HttpServletRequest request) throws IOException {
		BooksDTO dto = new BooksDTO();
		
		MultipartRequest req = new MultipartRequest(
				request, saveDirectory, maxPostSize, encoding, policy);
		
		File upload = req.getFile("upload");
		System.out.println("contentType:" + req.getContentType("upload"));
		
		boolean isNull = upload == null;
		
		// 작성자
		dto.setBooktitle(req.getParameter("booktitle"));
		dto.setBookwriter(req.getParameter("bookwriter"));
		dto.setPlot(req.getParameter("plot"));
		dto.setContent(req.getParameter("content"));
		dto.setBookphoto(isNull ? null : upload.getName());
		
		String idx1 = req.getParameter("idx");
		if(idx1 != null) {
			int idx2 = Integer.parseInt(idx1);
			dto.setIdx(idx2);
		}
		
		if(req.getParameter("deleteFile") != null) {
			deleteFile(req.getParameter("delete"));
			dto.setBookphoto("bookphoto=null");
		}
		return dto;
	}
		public int deleteFile(String bookphoto) {
			int row = 0;
			File f = new File(saveDirectory, bookphoto);
			if(f.exists()&&f.isFile()) {
				row = f.delete() ? 1 : 0;
			}
			return row;		
	}
		
		public BoardDTO getBoardDTO(HttpServletRequest request) throws IOException {
			BoardDTO dto = new BoardDTO();
			
			// 1) 파일이 있는가 없는가 판별하기
			MultipartRequest req = new MultipartRequest(
					request, saveDirectory, maxPostSize, encoding, policy);
			
			File upload = req.getFile("upload");	// <input type="file" name="upload">
			System.out.println("contentType : " + req.getContentType("upload"));
			
			
			boolean isNull = upload == null;
			
			// 작성자
			dto.setWriter(Integer.parseInt(req.getParameter("writer")));
			dto.setTitle(req.getParameter("title"));
			dto.setContent(req.getParameter("content"));
			dto.setIpaddr(request.getRemoteAddr());
			dto.setFileName(isNull ? null : upload.getName());
			
			String idx1 = req.getParameter("idx");
			if(idx1 != null) {
				int idx2 = Integer.parseInt(idx1);
				dto.setIdx(idx2);
			}
		
			if(req.getParameter("deleteFile") != null) {
				deleteFile(req.getParameter("delete"));
				dto.setFileName("fileName=null");	
			}
			return dto;
		}
		
		public int deleteBoardFile(String fileName) {
			int row = 0;
			File f = new File(saveDirectory, fileName);
			if(f.exists() && f.isFile()) {
				row = f.delete() ? 1 : 0;
			}
			return row;
		}
	
	

}
