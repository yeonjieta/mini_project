package books;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BooksDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private Context init;
	private DataSource ds;
	
	private static BooksDAO instance = new BooksDAO();
	
	public static BooksDAO getInstance() {
		return instance;
	}
	
	private BooksDAO() {
		try {
			init = new InitialContext();
			ds = (DataSource) init.lookup("java:comp/env/jdbc/oracle");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conn != null) conn.close();
		} catch (Exception e) {
		}
	}
	
	private BooksDTO mapping(ResultSet rs) throws SQLException {
		BooksDTO dto = new BooksDTO();
		dto.setIdx(rs.getInt("idx"));
		dto.setReader(rs.getInt("reader"));
		dto.setBooktitle(rs.getString("booktitle"));
		dto.setBookwriter(rs.getString("bookwriter"));
		dto.setBookphoto(rs.getString("bookphoto"));
		dto.setPlot(rs.getString("plot"));
		dto.setRental_status(rs.getInt("rental_status"));
		dto.setContent(rs.getString("content"));
//		dto.setUsername(rs.getString("username"));
		
		return dto;
	}
	
	// 도서 list 
	public List<BooksDTO> select(){
		ArrayList<BooksDTO> list = new ArrayList<BooksDTO>();
		String sql ="select * from books order by idx";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BooksDTO dto = new BooksDTO();
				dto.setIdx(rs.getInt("idx"));
				dto.setReader(rs.getInt("reader"));
				dto.setBooktitle(rs.getString("booktitle"));
				dto.setBookwriter(rs.getString("bookwriter"));
				dto.setBookphoto(rs.getString("bookphoto"));
				dto.setPlot(rs.getString("plot"));
				dto.setRental_status(rs.getInt("rental_status"));
				dto.setContent(rs.getString("content"));
				list.add(dto);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
	// 대여 확인 
	public int changeStatus(int idx) {
		int row = 0;
		String sql = "update books set rental_status = decode(rental_status, 0, 1, 1, 0) where idx =?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			row = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	
	// 도서추가(admin)
	public int insert(BooksDTO dto) {
		int row = 0;
		String sql = "insert into books(booktitle, bookwriter,bookphoto,plot,content) values (?,?,?,?,?)" ;
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getBooktitle());
			pstmt.setString(2, dto.getBookwriter());
			pstmt.setString(3, dto.getBookphoto());
			pstmt.setString(4, dto.getPlot());
			pstmt.setString(5, dto.getContent());
			row = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return row;
	}
	
	public int delete(int idx) {
		int row = 0;
		String sql = "delete books where idx=?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			row = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {

			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	public int update(BooksDTO dto) {
		int row = 0;
		String sql = "update books set booktitle=?, bookwriter=?, plot=?, content=?, bookphoto=? where idx =?";
		
//		boolean flag = dto.getBookphoto() != null;
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getBooktitle());
			pstmt.setString(2, dto.getBookwriter());
			pstmt.setString(3, dto.getPlot());
			pstmt.setString(4, dto.getContent());
			pstmt.setString(5, dto.getBookphoto());
			pstmt.setInt(6, dto.getIdx());
			row = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		
		return row;
		
	}
	

	public BooksDTO selectOne(int idx) { 
		BooksDTO  dto = null;
		String sql= "select * from books where idx=?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
			   dto = new BooksDTO();
				dto.setIdx(rs.getInt("idx"));
				dto.setBooktitle(rs.getString("booktitle"));
				dto.setBookwriter(rs.getString("bookwriter"));
				dto.setBookphoto(rs.getString("bookphoto"));
				dto.setPlot(rs.getString("plot"));
				dto.setRental_status(rs.getInt("rental_status"));
				dto.setContent(rs.getString("content"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		System.out.println(dto.getIdx());
		System.out.println(dto.getBooktitle());
		return dto;
	}
	
	// admin 검색
	public List<BooksDTO> adminSearch(String column, String search){
		ArrayList<BooksDTO> list = new ArrayList<BooksDTO>();
		String sql = "select * from books ";
		String like =" where lower(%s) like lower('%%' || ? || '%%') ";
		like = String.format(like, column);
		String order = " order by idx desc";
		boolean flag = "".equals(column) == false && "".equals(search) == false;
		sql += flag ? like + order : order;
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			if(flag) {
				pstmt.setString(1, search);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				list.add(mapping(rs));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		
		return list;
				
	}
	
	// admin 대여 현황
		public List<BooksDTO> adminRental(){
			ArrayList<BooksDTO> list = new ArrayList<BooksDTO>();
			String sql ="select O.myidx, B.bookphoto, B.booktitle, B.bookwriter, O.rentdate, B.rental_status, M.username "
					+ " from mybook O "
					+ " join books B on O.books = B.idx "
					+ " join members M on O.reader =  M.idx "
					+ " where B.rental_status=1 ";
//			SELECT 
//			B.*,
//			M.USERNAME
//			FROM BOOKS B
//			INNER JOIN MEMBERS M
//			    ON B.READER = M.IDX
	//
//			WHERE B.RENTAL_STATUS=1 ORDER BY B.IDX;
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					BooksDTO dto = new BooksDTO();
					dto.setIdx(rs.getInt("myidx"));
					dto.setBooktitle(rs.getString("booktitle"));
					dto.setBookwriter(rs.getString("bookwriter"));
					dto.setBookphoto(rs.getString("bookphoto"));
					dto.setRental_status(rs.getInt("rental_status"));
					dto.setRentdate(rs.getDate("rentdate"));
					dto.setUsername(rs.getString("username"));
					list.add(dto);
					
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}
			return list;
		}
		
		
		// 내서재
		public List<BooksDTO> rentSelect() {
			ArrayList<BooksDTO> list = new ArrayList<BooksDTO>();
			String sql = "select B.idx, O.myidx, B.bookphoto, B.booktitle, B.bookwriter, O.rentdate, B.rental_status, "
					+ " M.username "
					+ " from mybook O "
					+ " join books B on O.books = B.idx "
					+ " join members M on O.reader =  M.idx "
					+ " where B.rental_status=1 ";
			
			try {
				conn =ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
					BooksDTO dto = new BooksDTO();
					dto.setIdx(rs.getInt("idx"));
					dto.setMyidx(rs.getInt("myidx"));
					dto.setBooktitle(rs.getString("booktitle"));
					dto.setBookwriter(rs.getString("bookwriter"));
					dto.setBookphoto(rs.getString("bookphoto"));
					dto.setRentdate(rs.getDate("rentdate"));
					dto.setRental_status(rs.getInt("rental_status"));
					dto.setUsername(rs.getString("username"));
					list.add(dto);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}
			return list;
		}
		
		// change Reader
		public int inchangeReader(int useridx, int bookidx) {
			int row = 0;
			String sql = "update books set reader=? where idx=? ";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, useridx);
				pstmt.setInt(2, bookidx);
				row = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}
			return row;
		}
		
		public int outchangeReader(int bookidx) {
			int row = 0;
			String sql = "update books set reader=null where idx=? ";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, bookidx);
				row = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}
			return row;
		}
		
		public int mybookUpdate(int useridx, int bookidx) {
			int row = 0;
			String sql = "insert into mybook (reader, books) values ( ?, ?)";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, useridx);
				pstmt.setInt(2, bookidx);
				row = pstmt.executeUpdate();
				
			} catch(SQLException e) {
				e.printStackTrace();
			} finally { close();}
			return row;
		}
		public int mybookDelete(int myidx) {
			int row = 0;
			String sql ="delete from mybook where myidx=?";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, myidx);
				row = pstmt.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			} finally { close();}
			return row;
		}
		
		public BooksDTO selectReivew(int idx) { 
			BooksDTO  dto = null;
			String sql= "select * from books where idx=?";
			
			try {
				conn = ds.getConnection();
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, idx);
				rs = pstmt.executeQuery();
				
				while(rs.next()) {
				   dto = new BooksDTO();
				
					dto.setBooktitle(rs.getString("booktitle"));
					dto.setBookwriter(rs.getString("bookwriter"));
					dto.setBookphoto(rs.getString("bookphoto"));
					dto.setPlot(rs.getString("plot"));
					dto.setContent(rs.getString("content"));
				}
			} catch (SQLException e) {
				e.printStackTrace();
			} finally {
				close();
			}
	
			return dto;
		}
		
		

}
