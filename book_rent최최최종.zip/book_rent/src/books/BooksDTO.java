package books;

import java.sql.Date;

public class BooksDTO {

	
//	create table books (
//		    idx         number   default   books_seq.nextval primary key,
//		    reader     number,                         -- 외래키 members table (idx)
//		    booktitle    varchar2(100)   not null,
//		    bookwriter      varchar2(100)   not null,       -- 책 저자
//		    bookphoto   varchar2(255),                  -- 책 이미지
//		    plot        varchar2(2000) not null,        -- 책 줄거리
//		    rental_status      number          default 1 check(rental_status in (1,0)), -- 대출용 상태 확인
//		    content     varchar2(2000)  not null,       -- 책 내용 (미구현 가능성 있음)

	
	private int idx;
	private int reader;
	private String booktitle;
	private String bookwriter;
	private String bookphoto;
	private String plot;
	private int rental_status;
	private String content;
	private Date rentdate;
	private int myidx;
	
	public int getMyidx() {
		return myidx;
	}
	public void setMyidx(int myidx) {
		this.myidx = myidx;
	}
	public Date getRentdate() {
		return rentdate;
	}
	public void setRentdate(Date rentdate) {
		this.rentdate = rentdate;
	}
	private String username;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public int getReader() {
		return reader;
	}
	public void setReader(int reader) {
		this.reader = reader;
	}
	public String getBooktitle() {
		return booktitle;
	}
	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}
	public String getBookwriter() {
		return bookwriter;
	}
	public void setBookwriter(String bookwriter) {
		this.bookwriter = bookwriter;
	}
	public String getBookphoto() {
		return bookphoto;
	}
	public void setBookphoto(String bookphoto) {
		this.bookphoto = bookphoto;
	}
	public String getPlot() {
		return plot;
	}
	public void setPlot(String plot) {
		this.plot = plot;
	}
	public int getRental_status() {
		return rental_status;
	}
	public void setRental_status(int rental_status) {
		this.rental_status = rental_status;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	
	
}
