package members;

import java.sql.Date;

public class MembersDTO {

//	create table members (
//		    idx     number      default members_seq.nextval primary key,
//		    userid  varchar2(100)   unique,
//		    userpw  varchar2(100)   not null,
//		    useremail varchar2(100) not null,
//		    username varchar2(100) not null,
//		    grade    varchar2(100)  default 'user'      -- 관리자, user 구분용
//		);
	
	private int idx;
	private String userid;
	private String userpw;
	private String useremail;
	private String username;
	private String grade;
	private Date joindate;
	
	public Date getJoindate() {
		return joindate;
	}
	public void setJoindate(Date joindate) {
		this.joindate = joindate;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpw() {
		return userpw;
	}
	public void setUserpw(String userpw) {
		this.userpw = userpw;
	}
	public String getUseremail() {
		return useremail;
	}
	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	
}
