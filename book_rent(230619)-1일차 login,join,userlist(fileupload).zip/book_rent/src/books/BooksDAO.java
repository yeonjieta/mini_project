package books;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BooksDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private Context init;
	private DataSource ds;
	
	private static BooksDAO instance = new BooksDAO();
	
	public static BooksDAO getInstance() {
		return instance;
	}
	
	private BooksDAO() {
		try {
			init = new InitialContext();
			ds = (DataSource) init.lookup("java:comp/env/jdbc/oracle");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	public void close() {
		try {
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conn != null) conn.close();
		} catch (Exception e) {
		}
	}
	
	// 도서 list 
	public List<BooksDTO> select(){
		ArrayList<BooksDTO> list = new ArrayList<BooksDTO>();
		String sql ="select * from books order by idx";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BooksDTO dto = new BooksDTO();
				dto.setIdx(rs.getInt("idx"));
				dto.setReader(rs.getInt("reader"));
				dto.setBooktitle(rs.getString("booktitle"));
				dto.setBookwriter(rs.getString("bookwriter"));
				dto.setBookphoto(rs.getString("bookphoto"));
				dto.setPlot(rs.getString("plot"));
				dto.setRental_status(rs.getInt("rental_status"));
				dto.setContent(rs.getString("content"));
				list.add(dto);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return list;
	}
	
	// 대여 확인 
	public int changeStatus(int idx) {
		int row = 0;
		String sql = "update books set staus = decode(status, 1, 0, 0, 1) where idx =?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, rs.getInt("idx"));
			row = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return row;
	}
	
	
	// 도서추가(admin)
	public int insert(BooksDTO dto) {
		int row = 0;
		String sql = "insert into books(booktitle, bookwriter,bookphoto,plot,content) values (?,?,?,?,?)" ;
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getBooktitle());
			pstmt.setString(2, dto.getBookwriter());
			pstmt.setString(3, dto.getBookphoto());
			pstmt.setString(4, dto.getPlot());
			pstmt.setString(5, dto.getContent());
			row = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return row;
	}
	
	public BooksDTO selectOne(int idx) {
		BooksDTO  dto = new BooksDTO();
		String sql = "select * from books where idx =?";
		
		try {
			conn = ds.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, idx);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				dto.setIdx(rs.getInt("idx"));
				dto.setBooktitle(rs.getString("booktitle"));
				dto.setBookwriter(rs.getString("bookwriter"));
				dto.setBookphoto(rs.getString("bookphoto"));
				dto.setPlot(rs.getString("plot"));
				dto.setRental_status(rs.getInt("rental_status"));
				dto.setContent(rs.getString("content"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return dto;
	}
	

}
